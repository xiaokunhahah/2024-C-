import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from itertools import combinations
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
df = pd.read_excel('D:\\C题\\双对数回归模型结果.xlsx')
cols = df.columns[1:4]
# 将数据框中的非数值类型转换为 NaN，并且确保所有列的数据类型为浮点数
df = df.apply(pd.to_numeric, errors='coerce')
# 初始化存储结果的列表
results = []
# 计算子图的数量（取决于组合数）
num_combinations = len(list(combinations(cols, 2)))
# 创建子图
fig, axs = plt.subplots(1, num_combinations, figsize=(5 * num_combinations, 5))
# 确保 axs 是一维数组，以便后续的索引
if num_combinations == 1:
    axs = [axs]
# 遍历两两组合
for idx, (col1, col2) in enumerate(combinations(cols, 2)):
    # 提取当前两列数据
    x = df[col1].dropna().values  # 过滤掉 NaN 值
    y = df[col2].dropna().values  # 过滤掉 NaN 值
    # 检查数据是否为正数
    if np.any(x <= 0) or np.any(y <= 0):
        print(f"列 {col1} 和 {col2} 中含有非正值，跳过双对数分析")
        continue
    # 对自变量和因变量取对数
    x_log = np.log(x)
    y_log = np.log(y)
    # 在对应的子图中绘制散点图
    axs[idx].scatter(x_log, y_log)
    axs[idx].set_xlabel(f'log({col1})')
    axs[idx].set_ylabel(f'log({col2})')
    axs[idx].set_title(f'双对数散点图 {col1} vs {col2}')
    # 将数据转换为二维数组以适应线性回归模型
    x_log_reshaped = x_log.reshape(-1, 1)
    model = LinearRegression()
    model.fit(x_log_reshaped, y_log)
    alpha = model.intercept_
    beta = model.coef_[0]
    # 计算 R²
    r_squared = model.score(x_log_reshaped, y_log)
    # 将结果保存到列表
    results.append({
        '变量1': col1,
        '变量2': col2,
        '截距 (α)': alpha,
        '回归系数 (β)': beta,
        'R²': r_squared
    })
    print(f"分析完成: {col1} vs {col2}")
    print(f"截距（α）：{alpha}, 回归系数（β）：{beta}, R²：{r_squared}")
    print("-" * 50)
# 调整子图之间的间距
plt.tight_layout()
# 显示子图
plt.show()
# 将结果转换为数据框方便查看
results_df = pd.DataFrame(results)

