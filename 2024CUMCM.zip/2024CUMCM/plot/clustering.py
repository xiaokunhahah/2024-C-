from scipy.stats import spearmanr
import seaborn as sns

# 设置显示所有列和最大宽度
pd.set_option('display.max_rows', None)  # 显示所有行
pd.set_option('display.max_columns', None)  # 显示所有列
pd.set_option('display.width', None)  # 自动调整宽度以显示所有内容
pd.set_option('display.max_colwidth', None)  # 确保单元格内容不被截断
# 读取文件 并传入需要判断相关性的列名
df = df_extracted.copy()

columns = ['亩产量', '平均单价', '种植成本']
# 求解两两之间的 先关系数 并给出对应的显著性水平
# 初始化一个空的DataFrame，用于存储Spearman相关系数及p值
spearman_results_df = pd.DataFrame(index=columns, columns=columns)
spearman_results_df_plot = pd.DataFrame(index=columns, columns=columns)
# 计算 Spearman 相关系数及其检验
for i in range(len(columns)):
    for j in range(i, len(columns)):
        col1 = columns[i]
        col2 = columns[j]
        rho, pval = spearmanr(df[col1], df[col2])
        spearman_results_df.at[col1, col2] = f'{rho:.4f} (p={pval:.4f})'
        spearman_results_df.at[col2, col1] = f'{rho:.4f} (p={pval:.4f})'
        spearman_results_df_plot.at[col1, col2] = rho
        spearman_results_df_plot.at[col2, col1] = rho

for col in columns:
    spearman_results_df.at[col, col] = '1.0000 (p=0.0000)'
    spearman_results_df_plot.at[col, col] = 1.00
spearman_results_df.to_excel("D:\C题\spearman.xlsx")
spearman_results_df_plot.to_excel("D:\C题\spearman_plot.xlsx")
print(spearman_results_df)
# 绘制 Spearman 相关系数的热力图
plt.figure(figsize=(8, 6), dpi=300)
sns.heatmap(spearman_results_df_plot.astype(float), annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Spearman 相关系数热力图')
plt.show()