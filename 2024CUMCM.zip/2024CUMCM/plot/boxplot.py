import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm

plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus']=False
df = pd.read_excel('D:\C题\附件三销量.xlsx')

grouped = df.groupby('作物_区域_季')

df_sta = []

# 循环处理每个分组
for name, group in grouped:
    result = {}
    result['作物_区域_季'] = name
    result['总产量'] = (group['种植面积/亩'] * group['亩产量/斤']).sum()  # 总产量
    result['总种植成本'] = (group['种植面积/亩'] * group['种植成本/(元/亩)']).sum()  # 总种植成本
    result['平均销售单价'] = group['平均单价/(元/斤)'].mean()  # 平均销售单价
    result['作物类型'] = group['作物类型'].iloc[0]

    df_sta.append(result)

df_sta = pd.DataFrame(df_sta)

# 保存到 Excel 文件
df_sta.to_excel('D:\C题\农作物分组统计结果.xlsx', index=False)
df = pd.read_excel('D:\C题\农作物分组统计结果.xlsx')

# 按类别进行分组
grouped = df.groupby('作物类型')

# 创建一个 ExcelWriter 对象
with pd.ExcelWriter('D:\C题\双对数回归模型结果.xlsx') as writer:
    # 遍历每个分组，并分别写入不同的 sheet 中
    for name, group in grouped:
        group.to_excel(writer, sheet_name=str(name), index=False)
print("分组结果已保存到 '分组结果.xlsx'")

df1 = pd.read_excel('D:\C题\双对数回归模型结果.xlsx', sheet_name='粮食')
df2 = pd.read_excel('D:\C题\双对数回归模型结果.xlsx', sheet_name='蔬菜')

# 创建图形对象，并指定子图布局
fig, axs = plt.subplots(1, 2, figsize=(10, 4), dpi=150)
# 绘制 df1 的箱线图
axs[0].boxplot([df1['销量'], df1['总种植成本']], labels=['销量', '总种植成本'], widths=0.4)
axs[0].set_title('粮食类 箱线图')
# axs[0].grid(False)
# 绘制 df2 的箱线图
axs[1].boxplot([df2['销量'], df2['总种植成本']], labels=['销量', '总种植成本'], widths=0.4)
axs[1].set_title('蔬菜类 箱线图')
# axs[1].grid(False)
# 调整布局
plt.tight_layout()
# 显示图形
plt.show()

