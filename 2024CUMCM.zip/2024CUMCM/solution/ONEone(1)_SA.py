import numpy as np
import matplotlib.pyplot as plt
import math
import random
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
initial_temp = 100000
min_temp = 1e-4
alpha = 0.998
max_iter = 10000
years = 7
plots = 26
plants = 15
area = [80,55,35,72,68,55,60,46,40,28,25,86,55,44,50,25,60,45,35,20,15,13,15,18,27,20]
pinghan_chan = [400,500,400,350,415,800,1000,400,630,525,110,3000,2200,420,525]
titian_chan = [380,475,380,330,395,760,950,380,600,500,105,2850,2100,400,500]
shanpo_chan = [360,450,360,315,375,720,900,360,570,475,100,2700,2000,380,475]

pinghan_price = [3.25, 7.5, 8.25, 7, 6.75, 3.5, 3, 6.75, 6, 7.5, 40, 1.5, 3.25, 5.5, 3.5]
pinghan_cost =  [400,500,400,350,415,800,1000,400,630,525,110,3000,2200,420,525]
titian_price = [3.25, 7.5, 8.25, 7, 6.75, 3.5, 3, 6.75, 6, 7.5, 40, 1.5, 3.25, 5.5, 3.5]
titian_cost = [380,475,380,330,395,760,950,380,600,500,105,2850,2100,400,500]
shanpo_price = [3.25, 7.5, 8.25, 7, 6.75, 3.5, 3, 6.75, 6, 7.5, 40, 1.5, 3.25, 5.5, 3.5]
shanpo_cost =[360,450,360,315,375,720,900,360,570,475,100,2700,2000,380,475]
price = [3.25, 7.5, 8.25, 7, 6.75, 3.5, 3, 6.75, 6, 7.5, 40, 1.5, 3.25, 5.5, 3.5]
saled = [57000, 21850, 22400, 33040, 9875, 170840, 132750, 71400, 30000, 12500, 1500, 35100, 36000, 14000, 10000] # 2023年各农作物的销售量
values = []
temperatures = []

from utils_sa import simulated_annealing

best_solution, best_revenue = simulated_annealing()
plt.plot(values, label='目标函数值', color='orange')
plt.xlabel('迭代次数')
plt.ylabel('目标函数值')
plt.title('目标函数的变化')
plt.grid(True)
plt.legend()

plt.tight_layout()
plt.show()
np.set_printoptions(threshold=np.inf)
print("最佳方案:", best_solution)
print("最佳收益:", best_revenue)
