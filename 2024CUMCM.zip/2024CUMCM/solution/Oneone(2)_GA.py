import geatpy as ea
import numpy as np
import random
import pandas as pd
# 季度 我们将一年分为两个季度
years = 14
# 同时将水稻看作必须连着两季种的作物
plots = 28
plants = 26 # 农作物种类
# 水浇1 水浇2 普通大棚1 普通大棚2 智慧大棚1 智慧大棚2
area = [15,10,14,6,10,12,22,20,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6]
# 水浇地0-18
shuijiao_chan = [500,3000,2000,3000,2000,2400,6400,2700,2400,3300,3700,4100,3200,12000,4100,1600,10000,5000,5500,5000,4000,3000,0,0,0,0,0,0,0]
shuijiao_cost =[340,2000,1000,2000,2000,2000,2000,2300,1600,2400,2900,1600,1600,2900,1600,1000,4100,2000,900,2000,500,500,0,0,0,0,0,0,0]
# 普通大棚1-18、20-23
pupeng_chan = [0,3600,2400,3600,2400,3000,8000,3300,3000,4000,4500,5000,4000,15000,5000,2000,12000,6000,6600,0,0,0,5000,4000,10000,1000,0,0,0,0]
pupeng_cost = [0,2400,1200,2400,2400,2400,2400,2700,2000,3000,3500,2000,2000,3500,2000,1200,5000,2500,1100, 0,0,0,3000,2000,10000,10000]
# 智慧大棚一季度1-18
zhipeng1_chan = [0,3600,2400,3600,2400,3000,8000,3300,3000,4000,4500,5000,4000,15000,5000,2000,12000,6000,6600,0,0,0,0,0,0,0]
zhipeng1_cost = [0,2400,1200,2400,2400,2400,2400,2700,2000,3000,3500,2000,2000,3500,2000,1200,5000,2500,1100,0,0,0,0,0,0,0]
# 智慧大棚二季度1-18
zhipeng2_chan = [0, 3200,2200,3200,2200,2700,7200,3000,2700,3600,4100,4500,3600,13500,4500,1800,11000,5400,6000,0,0,0,0,0,0,0]
zhipeng2_cost =[0,2640,1320,2640,2640,2640,2640,3000,2200,3300,3850,2200,2200,3850,2200,1300,5500,2750,1200,0,0,0,0,0,0,0]
# 2023年销量
saled1 = [10500, 36480, 26880, 6480, 30000, 35400, 43200, 0, 1800, 3600, 4050, 4500, 34400, 9000, 1500, 1200, 3600, 1800, 0, 0, 0, 0, 0, 0, 0, 0]
saled2 = [10500, 0, 0, 0, 0, 810, 2160, 900, 810, 0, 0, 0, 1080, 4050, 1350, 0, 0, 0, 1800, 150000, 100000, 36000, 9000, 7200, 18000, 4200]
# 2023年第一季度售价
price1 = [3.5,8,6.75,6.5,3.75,6.25,5.5,5.75,5.25,5.5,6.5,5,5.75,7,5.25,7.25,4.5,4.5,4,0,0,0,0,0,0,0]
# 2023年第二季度售价
price2 = [3.5, 9.6,8.1,7.8,4.5,7.5,6.6,6.9,6.8,6.6,7.8,6,6.9,8.4,6.3,8.7,5.4,5.4,4.8,2.5,2.5,3.25,57.5,19,16,100]
# 目标函数
def aim_function(A, year):
    profit = 0  # 收益
    cost = 0  # 成本
    sale = np.zeros((years+2, plants))  # 初始化销售额为0
    # 计算销售额和种植面积
    for j in range(plots):
        plant = np.argmax(A[year][j])  # 获取当前土地选择的植物索引
        if j <= 7:
            sale[year][plant] += area[j] * shuijiao_chan[plant]
        elif 7 < j <= 23:
            sale[year][plant] += area[j] * pupeng_chan[plant]
        else:
            if year % 2 == 1:
                sale[year][plant] += area[j] * zhipeng1_chan[plant]
            else:
                sale[year][plant] += area[j] * zhipeng2_chan[plant]
    # 限制销售额不能超过 saled 的值
    for k in range(plants):
        if year % 2 == 0:
            if sale[year][k] > saled1[k]:
                sale[year][k] = saled1[k]
        else:
            if sale[year][k] > saled2[k]:
                sale[year][k] = saled2[k]
    # 计算成本
    for j in range(plots):
        plant = np.argmax(A[year][j])
        if j <= 7:
            cost += area[j] * shuijiao_cost[plant]
        elif 7 < j <= 23:
            cost += area[j] * pupeng_cost[plant]
        else:
            if year % 2 == 0:
                cost += area[j] * zhipeng1_cost[plant]
            else:
                cost += area[j] * zhipeng2_cost[plant]
    for k in range(plants):
        if year % 2 == 0:
            profit += sale[year][k] * price1[k]
        else:
            profit += sale[year][k] * price2[k]
    # 计算利润
    profit -= cost
    return profit
# 主修复函数，调用各个地块类型的修复函数
def repair_solution(solution, year):
    # 水浇地修复
    repair_shuijiao(solution, year)
    # 普通大棚修复
    repair_pupeng(solution, year)
    # 智慧大棚修复
    repair_zhipeng(solution, year)
    return solution
# 判断前n年是否种植了豆类作物（1-3）
def has_planted_bean(solution, j, year_block, n):
    return np.any(np.isin(np.argmax(solution[year_block:min(year_block + n, len(solution)), j], axis=1), [1, 2, 3]))
# 水浇地的修复
def repair_shuijiao(solution, year):
    years, blocks, crops = solution.shape
    irrigated_land = 8  # 前8块地为水浇地
    for j in range(irrigated_land):  # 只处理前8块水浇地
        current_crop = np.argmax(solution[year, j])  # 当前种植的作物索引
        if year % 2 == 0:
            # 判断是否前4年没种豆类
            if year >= 4 and not has_planted_bean(solution, j, year - 4, 4):
                # 必须种豆类（1-3）
                new_crop = random.randint(1, 3)
            else:
                # 在0-18之间随机选择
                new_crop = random.randint(0, 18)
            solution[year, j] = np.zeros(crops)
            solution[year, j, new_crop] = 1
        # 奇数年 (i=1, 3, 5... 实际年份 i+1=2, 4, 6...)
        else:
            # 如果上一年种了水稻（0）
            if year > 0 and np.argmax(solution[year - 1, j]) == 0:
                # 继续种水稻
                solution[year, j] = np.zeros(crops)
                solution[year, j, 0] = 1
            else:
                # 从19-21之间随机选择
                new_crop = random.randint(19, 21)
                solution[year, j] = np.zeros(crops)
                solution[year, j, new_crop] = 1
# 普通大棚的修复
def repair_pupeng(solution, year):
    years, blocks, crops = solution.shape
    start = 8  # 普通大棚从第8块开始
    pupeng = 16  # 普通大棚数量
    for j in range(start, start + pupeng):  # 只处理普通大棚
        current_crop = np.argmax(solution[year, j])
        # 偶数年 (i=0, 2, 4... 实际年份 i+1=1, 3, 5...)
        if year % 2 == 0:  # 偶数年
            # 判断是否前4年没种豆类
            if year >= 4 and not has_planted_bean(solution, j, year - 4, 4):
                # 必须种豆类（1-3）
                new_crop = random.randint(1, 3)
            else:
                # 在1-18之间随机选择
                new_crop = random.randint(1, 18)
            solution[year, j] = np.zeros(crops)
            solution[year, j, new_crop] = 1
        # 奇数年 (i=1, 3, 5... 实际年份 i+1=2, 4, 6...)
        else:
            # 从22-25之间随机选择菌类作物
            new_crop = random.randint(22, 25)
            solution[year, j] = np.zeros(crops)
            solution[year, j, new_crop] = 1
# 智慧大棚的修复
def repair_zhipeng(solution, year):
    years, blocks, crops = solution.shape
    start = 24  # 智慧大棚从第24块开始
    zhipeng = 4  # 智慧大棚数量
    for j in range(start, start + zhipeng):  # 只处理智慧大棚
        current_crop = np.argmax(solution[year, j])
        # 偶数年和奇数年 (i=0, 2, 4... 实际年份 i+1=1, 3, 5...)
        if year >= 5 and not has_planted_bean(solution, j, year - 5, 5):
            # 必须种豆类（1-3）
            new_crop = random.randint(1, 3)
        else:
            # 从1-18中随机选择，且不能与上一年相同
            previous_crop = np.argmax(solution[year - 1, j]) if year > 0 else -1
            new_crop = random.choice([k for k in range(1, 19) if k != previous_crop])
        solution[year, j] = np.zeros(crops)
        solution[year, j, new_crop] = 1

# 初始化种群
def initialize_population(solution, year):
    NIND = 50  # 种群大小
    Dim = plots * plants  # 仅优化当前年份的种植方案，维度为地块数 * 作物种类数
    Encoding = 'BG'  # 二进制编码

    # 随机生成种群 (NIND, Dim)
    population = np.random.randint(0, 2, (NIND, Dim))

    # 正确调用 ea.crtfld：需要二维数组作为 ranges 参数
    ranges = np.vstack([np.zeros(Dim), np.ones(Dim)])  # 变量的上下界，0 和 1
    borders = np.vstack([np.ones(Dim), np.ones(Dim)])  # 是否包含上下界，全部包含
    # 调用 crtfld 创建种群描述器
    Field = ea.crtfld(Encoding, np.array([1] * Dim), ranges, borders)
    # 返回 Population 对象
    return ea.Population(Encoding, Field, NIND)
# 遗传算法求解
def GA(solution, year):
    problem = MyProblem(solution, year)
    population = initialize_population(solution, year)

    # 使用适合二进制编码的算法模板
    algorithm = ea.soea_SGA_templet(problem, population)  # SGA 是标准遗传算法，适合二进制编码
    algorithm.MAXGEN = 2000  # 最大进化代数
    algorithm.mutOper.Pm = 0.2  # 变异概率
    algorithm.recOper.XOVR = 0.8  # 交叉概率
    algorithm.drawing = 0  # 设置绘图
    algorithm.logTras = 0
    algorithm.verbose = False

    # 求解问题
    res = ea.optimize(algorithm, verbose=False, drawing=0, outputMsg=False)
    # 从 res 中提取优化后的解
    best_variable = res['Vars'][-1]  # 获取最后一代的解（最优解）
    best_variable = best_variable.reshape(plots, plants)
    # 返回最优解
    print("最优收益：", res['ObjV'][0][0])
    return best_variable, res['ObjV'][0][0]
# 定义优化问题类
class MyProblem(ea.Problem):
    def __init__(self, solution, year):
        name = 'MyProblem'  # 问题名称
        M = 1  # 优化目标数量
        maxormins = [-1]  # 最大化目标
        Dim = years * plots * plants  # 决策变量总维数
        varTypes = [1] * Dim  # 决策变量类型，1表示二进制
        lb = np.zeros(Dim)  # 下界
        ub = np.ones(Dim)  # 上界
        lbin = np.ones(Dim)  # 下边界是否包含
        ubin = np.ones(Dim)  # 上边界是否包含
        self.year = year
        self.solution = solution
        super().__init__(name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)
    # 目标函数
    def aimFunc(self, pop):
        fitness = np.zeros(pop.sizes)  # 初始化适应度数组
        repaired_solution = repair_solution(self.solution, self.year)  # 修复指定年份的方案
        fitness[self.year] = aim_function(repaired_solution, self.year)  # 计算该解的目标函数值（利润）
        pop.ObjV = fitness.reshape(-1, 1)  # 将适应度赋给种群的目标值矩阵
# 逐年优化函数
def optimize_yearly(solution):
    profit_sum = 0
    for i in range(2, years+2):  # 从 year=1 开始逐年优化
        year = i
        better_solution, best_value = GA(solution, year)
        profit_sum += best_value
        solution[year] = better_solution
        repaired_solution = repair_solution(solution, year)
        solution = repaired_solution
    print(profit_sum)
    return solution
# 主函数
def main(solution):
    # 逐年优化种植方案
    best_solution = optimize_yearly(solution)
    # 输出每一年的最优种植方案
    for year in range(2, years+2):
        print(f"第 {year} 年的最优种植方案:")
        for plot in range(plots):
            crop = np.argmax(best_solution[year][plot])  # 获取每块地的种植作物
            print(f"  地块 {plot + 1}: 种植作物 {crop}")
if __name__ == '__main__':
    solution = np.zeros((years + 2, plots, plants))
    # 初始化2023年解 (year=0/1)
    solution[0] = []
    solution[1] = []
    main(solution)
    # 将 area 列表转换为数组
    area_array = np.array(area).reshape(-1, 1)  # 转为列向量，便于后续逐元素相乘
    solution_scaled = solution * area_array
    # 保存矩阵到 Excel 中的不同 sheet
    with pd.ExcelWriter('D:\\C题\问题一_1.2.xlsx') as writer:
        # 从第二个矩阵开始保存 (跳过第一个矩阵)
        for i in range(0 ,solution_scaled.shape[0]):
            # 提取第 i 个矩阵
            matrix = solution_scaled[i]
            # 将矩阵转换为 DataFrame
            df = pd.DataFrame(matrix)
            # 将 DataFrame 保存到 Excel 文件中，使用不同的 sheet 名称
            df.to_excel(writer, sheet_name=f'Matrix_{i}', index=False)
    print("处理后的矩阵已保存到 Excel 文件的不同 sheet 中。")
    print("矩阵已经保存到 Excel 文件中")
