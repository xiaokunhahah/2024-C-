 # 目标函数
def aim_function(A, year):
    profit = 0  # 收益
    cost = 0  # 成本
    sale = np.zeros((years+2, plants))  # 初始化销售额为0
    # 计算销售额和种植面积
    for j in range(plots):
        plant = np.argmax(A[year][j])  # 获取当前土地选择的植物索引
        if j <= 7:
            sale[year][plant] += area[j] * shuijiao_chan[plant]
        elif 7 < j <= 23:
            sale[year][plant] += area[j] * pupeng_chan[plant]
        else:
            if year % 2 == 1:
                sale[year][plant] += area[j] * zhipeng1_chan[plant]
            else:
                sale[year][plant] += area[j] * zhipeng2_chan[plant]
    # 限制销售额不能超过 saled 的值
    for k in range(plants):
        if year % 2 == 0:
            if sale[year][k] > saled1[k]:
                profit += 0.5 * price1[k] * (sale[year][k] - saled1[k])
                sale[year][k] = saled1[k]
        else:
            if sale[year][k] > saled2[k]:
                profit += 0.5 * price2[k] * (sale[year][k] - saled2[k])
                sale[year][k] = saled2[k]
    # 计算成本
    for j in range(plots):
        plant = np.argmax(A[year][j])
        if j <= 7:
            cost += area[j] * shuijiao_cost[plant]
        elif 7 < j <= 23:
            cost += area[j] * pupeng_cost[plant]
        else:
            if year % 2 == 0:
                cost += area[j] * zhipeng1_cost[plant]
            else:
                cost += area[j] * zhipeng2_cost[plant]
    for k in range(plants):
        if year % 2 == 0:
            profit += sale[year][k] * price1[k]
        else:
            profit += sale[year][k] * price2[k]

    # 计算利润
    profit -= cost
    return profit
