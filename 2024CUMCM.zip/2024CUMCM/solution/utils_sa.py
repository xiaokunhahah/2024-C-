import numpy as np
import matplotlib.pyplot as plt
import math

def initialize_solution():
    A = np.zeros((years, plots, plants), dtype = int)
    for i in range(years):
        for j in range(plots):
            plant_choice = random.randint(0, plants - 1)
            A[i][j][plant_choice] = 1
    return A


def objective_function(A, Area):
    profit = 0  # 总收益
    cost = 0  # 总成本
    sale = np.zeros((years, plants))  # 初始化每年每个作物的产量（销售量）
    # 计算各块地每年的销售量（产量）
    for i in range(years):
        for j in range(plots):
            for k in range(plants):
                if j <= 5:  # 平旱地
                    sale[i][k] += A[i][j][k] * area[j] * pinghan_chan[k]
                elif 6 <= j <= 19:  # 梯田
                    sale[i][k] += A[i][j][k] * area[j] * titian_chan[k]
                else:  # 山坡地
                    sale[i][k] += A[i][j][k] * area[j] * shanpo_chan[k]

    # 限制每年的销售量不能超过 saled
    for i in range(years):
        for k in range(plants):
            if sale[i][k] > saled[k]:  # 限制每个作物的销售量
                sale[i][k] = saled[k]
    # 计算成本
    for i in range(years):
        for j in range(plots):
            for k in range(plants):
                if j <= 5:  # 平旱地
                    cost += A[i][j][k] * area[j] * pinghan_cost[k]
                elif 6 <= j <= 19:  # 梯田
                    cost += A[i][j][k] * area[j] * titian_cost[k]
                else:  # 山坡地
                    cost += A[i][j][k] * area[j] * shanpo_cost[k]
    # 计算总销售收益（销售量 * 价格）
    for k in range(plants):
        for i in range(years):
            profit += sale[i][k] * price[k]
    # 计算最终利润 = 收益 - 成本
    profit -= cost
    return profit


def repair_solution(solution):
    for i in range(years):
        for j in range(plots):
            plants_in_plot = solution[i][j]
            # 确保每块地只能种植一种植物
            if np.sum(plants_in_plot) == 0:
                # 如果没有植物被种植，随机种植一个植物
                random_plant = np.random.randint(0, plants)
                plants_in_plot[random_plant] = 1
            elif np.sum(plants_in_plot) > 1:
                # 如果种植了多个植物，选择收益最高的植物保留
                best_plant = None
                best_profit = -np.inf
                for k in range(plants):
                    if plants_in_plot[k] == 1:
                        if j <= 5:
                            profit = area[j] * pinghan_chan[k]
                        elif 5 < j <= 19:
                            profit = area[j] * titian_chan[k]
                        else:
                            profit = area[j] * shanpo_chan[k]
                        if profit > best_profit:
                            best_profit = profit
                            best_plant = k
                # 清空种植，保留收益最高的植物
                solution[i][j] = np.zeros(plants)
                solution[i][j][best_plant] = 1
            # 农作物轮作约束（确保第一年和第二年不同）
            if i >= 1:  # 第二年及以后
                first_year_plant = np.argmax(solution[0][j])  # 第一年的植物
                if plants_in_plot[first_year_plant] == 1:  # 如果相同，随机选择一个不同的植物
                    possible_plants = np.delete(np.arange(plants), first_year_plant)
                    new_plant = np.random.choice(possible_plants)
                    solution[i][j] = np.zeros(plants)
                    solution[i][j][new_plant] = 1
        # 每三年种植一次豆类的约束
        for j in range(plots):
            for year_group in range(0, years, 3):  # 每三年检查一次
                has_legume = False
                for i in range(year_group, min(year_group + 3, years)):  # 检查三年内是否种植了豆类
                    if np.sum(solution[i][j][:5]) > 0:  # 豆类的索引为0到4
                        has_legume = True
                        break
                if not has_legume:
                    # 如果三年内没有种植豆类，强制在最后一年种植豆类
                    random_legume = np.random.randint(0, 5)  # 选择一个豆类
                    last_year = min(year_group + 2, years - 1)
                    solution[last_year][j] = np.zeros(plants)  # 清空其他种植
                    solution[last_year][j][random_legume] = 1
    return solution


def is_valid(A):
    for i in range(years - 1):
        for j in range(plots):
            for k in range(plants):
                if A[i][j][k] == A[i + 1][j][k]:
                    return False
    for j in range(plots):
        for i in range(years - 2):  # 检查每个三年
            legume_planted = False
            for y in range(i, i + 3):
                for k in range(5):
                    if A[y][j][k] == 1:
                        legume_planted = True
                        break
                if not legume_planted:
                    return False


def neighbour(A):
    new_A = A.copy()
    i = random.randint(0, years - 1)
    j = random.randint(0, plots - 1)
    current_plant = np.argmax(A[i][j])
    new_plant = random.randint(0, plants - 1)
    while new_plant == current_plant:
        new_plant = random.randint(0, plants - 1)
    new_A[i][j][current_plant] = 0
    new_A[i][j][new_plant] = 1
    for i in range(years):
        A[i] = repair_solution(A[i])
    return new_A


def simulated_annealing():
    current_solution = initialize_solution()
    current_value = objective_function(current_solution, area)
    best_solution = current_solution.copy()
    best_value = current_value
    temp = initial_temp
    solution_num = 0
    for i in range(max_iter):
        new_solution = neighbour(current_solution)
        new_value = objective_function(new_solution, area)
        delta_E = new_value - current_value
        if is_valid(new_solution) == False:
            continue
        if delta_E > 0 or math.exp(delta_E / temp) > random.random():
            current_solution = new_solution
            current_value = new_value
            if new_value > best_value:
                best_value = new_value
                best_solution = new_solution
            solution_num += 1
        temp *= alpha
        values.append(current_value)
        temperatures.append(temp)
        if solution_num == 5:
            break
        print(temp, " 最佳目标值")
        print(best_value)
        print('\n')
    return best_solution, best_value