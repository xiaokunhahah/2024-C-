import geatpy as ea
import numpy as np
import random
import pandas as pd
# 季度 我们将一年分为两个季度
years = 14
# 同时将水稻看作必须连着两季种的作物
plots = 28
plants = 26 # 农作物种类
# 水浇1 水浇2 普通大棚1 普通大棚2 智慧大棚1 智慧大棚2
area = [15,10,14,6,10,12,22,20,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6]
# 预测未来量
output = np.zeros((years, plots, plants))  # 亩产量
cost = np.zeros((years, plots, plants))  # 种植成本
price = np.zeros((years, plants))  # 销售单价
need = np.zeros((years, plants))  # 市场需求量
def forecast_2(alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3):
    # 市场需求量
    need_2023 = np.zeros((2, plants))
    need_2023[0] = [10500, 36480, 26880, 6480, 30000, 35400, 43200, 0, 1800, 3600, 4050, 4500, 34400, 9000, 1500, 1200,
                    3600, 1800, 0, 0, 0, 0, 0, 0, 0, 0]
    need_2023[1] = [10500, 0, 0, 0, 0, 810, 2160, 900, 810, 0, 0, 0, 1080, 4050, 1350, 0, 0, 0, 1800, 150000, 100000,
                    36000, 9000, 7200, 18000, 4200]
    for i in range(years):
        for k in range(plants):
            if i % 2 == 0:
                need[i][k] = need_2023[0][k] * (1+alpha_2) # 偶数年，使用第一季的需求量
            else:
                need[i][k] = need_2023[1][k] * (1+alpha_2)  # 奇数年，使用第二季的需求量
    #print('第一年需求量')
    #print(need[0])
    #print(need[1])
    # 亩产量
    shuijiao_chan = []
    pupeng_chan = []
    zhipeng1_chan = []
    zhipeng2_chan = []
    output_2023 = np.zeros((2, plots, plants))
    output_2023[0, :8] = shuijiao_chan  # 第一季水浇地的产量
    output_2023[1, :8] = shuijiao_chan  # 第二季水浇地的产量（相同）
    output_2023[0, 8:24] = pupeng_chan  # 第一季普通大棚的产量
    output_2023[1, 8:24] = pupeng_chan  # 第二季普通大棚的产量（相同）
    output_2023[0, 24:] = zhipeng1_chan  # 第一季智慧大棚的产量
    output_2023[1, 24:] = zhipeng2_chan  # 第二季智慧大棚的产量
    for i in range(years):
        for j in range(plots):
            for k in range(plants):
                if i % 2 == 0:
                    output[i][j][k] = output_2023[0][j][k] * (1+beta)
                else:
                    output[i][j][k] = output_2023[1][j][k] * (1+beta)
    # 种植成本
    shuijiao_cost = []
    pupeng_cost = []
    zhipeng1_cost = []
    zhipeng2_cost =[]
    cost_2023 = np.zeros((2, plots, plants))
    for i in range(8):  # 水浇地前8块地
        cost_2023[0][i] = shuijiao_cost
        cost_2023[1][i] = shuijiao_cost
    for i in range(8, 24):  # 普通大棚
        cost_2023[0][i] = pupeng_cost
        cost_2023[1][i] = pupeng_cost
    for i in range(24, plots):  # 智慧大棚
        cost_2023[0][i] = zhipeng1_cost
        cost_2023[1][i] = zhipeng2_cost
    for i in range(years):
        for j in range(plots):
            for k in range(plants):
                if i == 0:
                    cost[i][j][k] = cost_2023[0][j][k] * (1 + gamma)  # 第一年的种植成本
                elif i == 1:
                    cost[i][j][k] = cost_2023[1][j][k] * (1 + gamma)  # 第二年的种植成本
                else:
                    cost[i][j][k] = cost[i - 2][j][k] * (1 + gamma)  # 第三年及以后的成本基于两年前的成本调整
    # 销售单价
    price_2023 = np.zeros((2, plants))
    # 2023年第一季度售价
    price_2023[0] = [3.5, 8, 6.75, 6.5, 3.75, 6.25, 5.5, 5.75, 5.25, 5.5, 6.5, 5, 5.75, 7, 5.25, 7.25, 4.5, 4.5, 4, 0,
                     0, 0, 0, 0, 0, 0]
    # 2023年第二季度售价
    price_2023[1] = [3.5, 9.6, 8.1, 7.8, 4.5, 7.5, 6.6, 6.9, 6.8, 6.6, 7.8, 6, 6.9, 8.4, 6.3, 8.7, 5.4, 5.4, 4.8, 2.5,
                     2.5, 3.25, 57.5, 19, 16, 100]
    # 根据每年的年份计算未来价格
    for i in range(years):
        for k in range(1, plants):
            # 奇偶年交替使用2023年价格
            if i % 2 == 0:
                base_price = price_2023[0][k]
            else:
                base_price = price_2023[1][k]
            # 根据作物种类调整价格
            if k <= 21:  # 蔬菜类
                price[i][k] = base_price * (1 + eta_1) ** (i // 2)  # 每两年累积增长 eta_1
            elif k == 25:  # 羊肚菌
                price[i][k] = base_price * (1 + eta_3) ** (i // 2)  # 每两年累积增长 eta_3
            else:  # 食用菌
                price[i][k] = base_price * (1 + eta_2) ** (i // 2)  # 每两年累积增长 eta_2
    # 返回结果
    return output, need, cost, price
# 目标函数
def aim_function(A, year):
    profit = 0  # 总收益
    cost_num = 0  # 总成本
    sale = np.zeros((years+2, plants))  # 初始化每年每个作物的产量（销售量）
    # 计算产量和成本
    for j in range(plots):
        for k in range(plants):
            sale[year][k] += A[year][j][k] * area[j] * output[year-2][j][k]
            cost_num += A[year][j][k] * area[j] * cost[year-2][j][k]
    # print('第一年产量')
    # print(sale[0])
    # print(sale[1])
    # 限制每年的销售量不能超过 saled
    loss_num = 0
    for k in range(plants):
        if sale[year][k] > need[year-2][k]:  # 限制每个作物的销售量
            loss_num += sale[year-2][k] - need[year-2][k]
            sale[year][k] = need[year-2][k]
    # print(loss_num)
    # print(f"Year {i + 1}: Sale = {sale[i]}, Need = {need[i]}, Cost = {cost_num}")
    # 计算总收益
    for k in range(plants):
        profit += sale[year][k] * price[year-2][k]
    # 计算最终利润 = 收益 - 成本
    profit -= cost_num
    return profit
# 主修复函数，调用各个地块类型的修复函数
def repair_solution(solution, year):
    # 水浇地修复
    repair_shuijiao(solution, year)
    # 普通大棚修复
    repair_pupeng(solution, year)
    # 智慧大棚修复
    repair_zhipeng(solution, year)
    return solution

# 判断前n年是否种植了豆类作物（1-3）
def has_planted_bean(solution, j, year_block, n):
    return np.any(np.isin(np.argmax(solution[year_block:min(year_block + n, len(solution)), j], axis=1), [1, 2, 3]))

# 水浇地的修复
def repair_shuijiao(solution, year):
    years, blocks, crops = solution.shape
    irrigated_land = 8  # 前8块地为水浇地
    for j in range(irrigated_land):  # 只处理前8块水浇地
        current_crop = np.argmax(solution[year, j])  # 当前种植的作物索引
        if year % 2 == 0:
            if np.argmax(solution[year - 1, j]) == 0:
                new_crop = random.randint(1, 18)
            # 判断是否前4年没种豆类
            else:
                if year >= 4 and not has_planted_bean(solution, j, year - 4, 4):
                    # 必须种豆类（1-3）
                    new_crop = random.randint(1, 3)
                else:
                    # 在0-18之间随机选择
                    new_crop = random.randint(0, 18)
            solution[year, j] = np.zeros(crops)
            solution[year, j, new_crop] = 1
        # 奇数年 (i=1, 3, 5... 实际年份 i+1=2, 4, 6...)
        else:
            # 如果上一年种了水稻（0）
            if year > 0 and np.argmax(solution[year - 1, j]) == 0:
                # 继续种水稻
                solution[year, j] = np.zeros(crops)
                solution[year, j, 0] = 1
            else:
                # 从19-21之间随机选择
                new_crop = random.randint(19, 21)
                solution[year, j] = np.zeros(crops)
                solution[year, j, new_crop] = 1
# 普通大棚的修复
def repair_pupeng(solution, year):
    years, blocks, crops = solution.shape
    start = 8  # 普通大棚从第8块开始
    pupeng = 16  # 普通大棚数量
    for j in range(start, start + pupeng):  # 只处理普通大棚
        current_crop = np.argmax(solution[year, j])
        # 偶数年 (i=0, 2, 4... 实际年份 i+1=1, 3, 5...)
        if year % 2 == 0:  # 偶数年
            # 判断是否前4年没种豆类
            if year >= 4 and not has_planted_bean(solution, j, year - 4, 4):
                # 必须种豆类（1-3）
                new_crop = random.randint(1, 3)
            else:
                # 在1-18之间随机选择
                new_crop = random.randint(1, 18)
            solution[year, j] = np.zeros(crops)
            solution[year, j, new_crop] = 1
        # 奇数年 (i=1, 3, 5... 实际年份 i+1=2, 4, 6...)
        else:
            # 从22-25之间随机选择菌类作物
            new_crop = random.randint(22, 25)
            solution[year, j] = np.zeros(crops)
            solution[year, j, new_crop] = 1
# 智慧大棚的修复
def repair_zhipeng(solution, year):
    years, blocks, crops = solution.shape
    start = 24  # 智慧大棚从第24块开始
    zhipeng = 4  # 智慧大棚数量
    for j in range(start, start + zhipeng):  # 只处理智慧大棚
        current_crop = np.argmax(solution[year, j])
        # 偶数年和奇数年 (i=0, 2, 4... 实际年份 i+1=1, 3, 5...)
        if year >= 5 and not has_planted_bean(solution, j, year - 5, 5):
            # 必须种豆类（1-3）
            new_crop = random.randint(1, 3)
        else:
            # 从1-18中随机选择，且不能与上一年相同
            previous_crop = np.argmax(solution[year - 1, j]) if year > 0 else -1
            new_crop = random.choice([k for k in range(1, 19) if k != previous_crop])
        solution[year, j] = np.zeros(crops)
        solution[year, j, new_crop] = 1
# 初始化种群
def initialize_population(solution, year):
    NIND = 50  # 种群大小
    Dim = plots * plants  # 仅优化当前年份的种植方案，维度为地块数 * 作物种类数
    Encoding = 'BG'  # 二进制编码
    # 随机生成种群 (NIND, Dim)
    population = np.random.randint(0, 2, (NIND, Dim))
    # 正确调用 ea.crtfld：需要二维数组作为 ranges 参数
    ranges = np.vstack([np.zeros(Dim), np.ones(Dim)])  # 变量的上下界，0 和 1
    borders = np.vstack([np.ones(Dim), np.ones(Dim)])  # 是否包含上下界，全部包含
    # 调用 crtfld 创建种群描述器
    Field = ea.crtfld(Encoding, np.array([1] * Dim), ranges, borders)
    # 返回 Population 对象
    return ea.Population(Encoding, Field, NIND)
# 遗传算法求解
def GA(solution, year):
    problem = MyProblem(solution, year)
    population = initialize_population(solution, year)
    # 使用适合二进制编码的算法模板
    algorithm = ea.soea_SGA_templet(problem, population)  # SGA 是标准遗传算法，适合二进制编码
    # 求解问题
    res = ea.optimize(algorithm, verbose=False, drawing=0, outputMsg=False)
    # 从 res 中提取优化后的解
    best_variable = res['Vars'][-1]  # 获取最后一代的解（最优解）
    best_variable = best_variable.reshape(plots, plants)
    # 返回最优解
    print("最优收益：", res['ObjV'][0][0])
    return best_variable, res['ObjV'][0][0]
# 定义优化问题类
class MyProblem(ea.Problem):
    def __init__(self, solution, year):
        name = 'MyProblem'  # 问题名称
        M = 1  # 优化目标数量
        maxormins = [-1]  # 最大化目标
        Dim = years * plots * plants  # 决策变量总维数
        varTypes = [1] * Dim  # 决策变量类型，1表示二进制
        lb = np.zeros(Dim)  # 下界
        ub = np.ones(Dim)  # 上界
        lbin = np.ones(Dim)  # 下边界是否包含
        ubin = np.ones(Dim)  # 上边界是否包含
        self.year = year
        self.solution = solution
        super().__init__(name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)
    # 目标函数
    def aimFunc(self, pop):
        fitness = np.zeros(pop.sizes)  # 初始化适应度数组
        repaired_solution = repair_solution(self.solution, self.year)  # 修复指定年份的方案
        fitness[self.year] = aim_function(repaired_solution, self.year)  # 计算该解的目标函数值（利润）
        pop.ObjV = fitness.reshape(-1, 1)  # 将适应度赋给种群的目标值矩阵
# 逐年优化函数
def optimize_yearly(solution):
    # 参数设置
    forecast_2(alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3)
    profit_sum = 0
    for i in range(2, years+2):  # 从 year=1 开始逐年优化
        year = i
        better_solution, best_value = GA(solution, year)
        profit_sum += best_value
        solution[year] = better_solution
        repaired_solution = repair_solution(solution, year)
        solution = repaired_solution
    print(profit_sum)
    return solution
# 主函数
def main(solution):
    # 逐年优化种植方案
    best_solution = optimize_yearly(solution)
    # 输出每一年的最优种植方案
    for year in range(2, years+2):
        print(f"第 {year} 年的最优种植方案:")
        for plot in range(plots):
            crop = np.argmax(best_solution[year][plot])  # 获取每块地的种植作物
            print(f"  地块 {plot + 1}: 种植作物 {crop}")
if __name__ == '__main__':
    solution = np.zeros((years + 2, plots, plants))
    # 初始化2023年解 (year=0/1)
    solution[0] = []
    solution[1] = []
    main(solution)
    print(solution)
