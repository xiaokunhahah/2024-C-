import geatpy as ea
import numpy as np
import random
import pandas as pd

# data
years = 7  # 年份
plots = 26  # 地块数
plants = 15  # 农作物种类
area = [80, 55, 35, 72, 68, 55, 60, 46, 40, 28, 25, 86, 55, 44, 50, 25, 60, 45, 35, 20, 15, 13, 15, 18, 27, 20]  # 各地块面积
pinghan_cost = [400, 500, 400, 350, 415, 800, 1000, 400, 630, 525, 110, 3000, 2200, 420, 525]  # 平旱地各农作物的成本
titian_cost = [380, 475, 380, 330, 395, 760, 950, 380, 600, 500, 105, 2850, 2100, 400, 500]  # 梯田各农作物的成本
shanpo_cost = [360, 450, 360, 315, 375, 720, 900, 360, 570, 475, 100, 2700, 2000, 380, 475]  # 山坡地各农作物的成本
price = [3.25, 7.5, 8.25, 7, 6.75, 3.5, 3, 6.75, 6, 7.5, 40, 1.5, 3.25, 5.5, 3.5]  # 各农作物的价格
saled = [57000, 21850, 22400, 33040, 9875, 170840, 132750, 71400, 30000, 12500, 1500, 35100, 36000, 14000, 10000]  # 2023年各农作物的销售量
pinghan_chan = [400, 500, 400, 350, 415, 800, 1000, 400, 630, 525, 110, 3000, 2200, 420, 525] # 平旱地各农作物的种植成本
titian_chan = [380, 475, 380, 330, 395, 760, 950, 380, 600, 500, 105, 2850, 2100, 400, 500] # 梯田各农作物的种植成本
shanpo_chan = [360, 450, 360, 315, 375, 720, 900, 360, 570, 475, 100, 2700, 2000, 380, 475] # 山坡地各农作物的种植成本

# 目标函数
from utils_ga import optimize_yearly

# 主函数
def main(solution):
    # 逐年优化种植方案
    best_solution = optimize_yearly(solution)
    # 输出每一年的最优种植方案
    for year in range(1, years+1):
        print(f"第 {year} 年的最优种植方案:")
        for plot in range(plots):
            crop = np.argmax(best_solution[year][plot])  # 获取每块地的种植作物
            print(f"地块 {plot + 1}: 种植作物 {crop}")

if __name__ == '__main__':
    solution = np.zeros((years + 1, plots, plants))
    # 初始化2023年解 (year=0)
    solution[0] = np.zeros((plots, plants))
    # 初始方案
    num = [5, 6, 6, 0, 3, 7, 5, 1, 2, 3, 4, 7, 5, 7, 8, 9, 0, 6, 13, 14, 10, 11, 0, 12, 5, 2]
    for j, k in enumerate(num):
        solution[0, j, k] = 1
    main(solution)
    # 将 area 列表转换为数组
    area_array = np.array(area).reshape(-1, 1)  # 转为列向量，便于后续逐元素相乘
    solution_scaled = solution * area_array
    # 保存矩阵到 Excel 中的不同 sheet
    with pd.ExcelWriter('D:\\C题\问题一_1.1.xlsx') as writer:
        # 从第二个矩阵开始保存 (跳过第一个矩阵)
        for i in range(0 ,solution_scaled.shape[0]):
            # 提取第 i 个矩阵
            matrix = solution_scaled[i]
            # 将矩阵转换为 DataFrame
            df = pd.DataFrame(matrix)
            # 将 DataFrame 保存到 Excel 文件中，使用不同的 sheet 名称
            df.to_excel(writer, sheet_name=f'Matrix_{i}', index=False)
    print("处理后的矩阵已保存到 Excel 文件的不同 sheet 中。")
    print("矩阵已经保存到 Excel 文件中")
