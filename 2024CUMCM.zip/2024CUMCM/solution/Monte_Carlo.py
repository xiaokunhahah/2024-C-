import geatpy as ea
import numpy as np
import random
# 已知量
years1 = 7  # 年份
plots1 = 26  # 地块数
plants1 = 15  # 农作物种类
area1 = [80, 55, 35, 72, 68, 55, 60, 46, 40, 28, 25, 86, 55, 44, 50, 25, 60, 45, 35, 20, 15, 13, 15, 18, 27, 20]  # 各地块面积
# 季度 我们将一年分为两个季度
years = 14
# 同时将水稻看作必须连着两季种的作物
plots = 28
plants = 26 # 农作物种类
# 水浇1 水浇2 普通大棚1 普通大棚2 智慧大棚1 智慧大棚2
area = [15,10,14,6,10,12,22,20,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6,0.6]
# 预测未来量
output1 = np.zeros((years1, plots1, plants1)) # 亩产量
cost1 = np.zeros((years1, plots1, plants1)) # 种植成本
price1 = np.zeros((years1, plants1)) # 销售单价
need1 = np.zeros((years1, plants1)) # 市场需求量
def forecast_1(alpha_1, alpha_2, beta, gamma):
    return output, need, cost, price
# 目标函数
def aim_function1(A, year):
    return profit
def aim_function2(A, year):
    return profit
# 判断三年内是否种植过豆类（下标为0-4的作物）
def has_planted_bean(solution, plot, start_year, window):
    for year in range(start_year, start_year + window):
        if np.any(solution[year][plot][0:5] == 1):  # 种植了豆类
            return True
    return False
# 修复解，使每个地块只种植一种作物
def repair_solution1(solution, year):
    return solution  # 返回修复后的方案
def repair_solution2(solution, year):
    return solution  # 返回修复后的方案
# 水浇地的修复
def repair_shuijiao(solution, year):
# 普通大棚的修复
def repair_pupeng(solution, year):
# 智慧大棚的修复
def repair_zhipeng(solution, year):
# 初始化种群
def initialize_population1(solution, year):
    return ea.Population(Encoding, Field, NIND)
def initialize_population2(solution, year):
    return ea.Population(Encoding, Field, NIND)
# 遗传算法求解
def GA1(solution, year):
    return best_variable, res['ObjV'][0][0]
def GA2(solution, year):
    return best_variable, res['ObjV'][0][0]
# 定义优化问题类
class MyProblem1(ea.Problem):
    def __init__(self, solution, year):
    # 目标函数
    def aimFunc(self, pop):
class MyProblem2(ea.Problem):
    # 目标函数
    def aimFunc(self, pop):
# 逐年优化函数
def optimize_yearly1(solution, alpha_1, alpha_2, beta, gamma):
    return solution, profit_sum
def optimize_yearly2(solution, alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3):
    return solution, profit_sum
# 主函数
def main1(solution,alpha_1, alpha_2, beta, gamma):
    # 逐年优化种植方案
    best_solution, profit = optimize_yearly1(solution,alpha_1, alpha_2, beta, gamma)
    return profit
def main2(solution,alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3):
    # 逐年优化种植方案
    best_solution, profit = optimize_yearly2(solution,alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3)
    return profit
def monte_carlo(num_samples):
    for i in range(num_samples):
        alpha_1 = random.uniform(0.05, 0.10)
        alpha_2 = random.uniform(-0.05, 0.05)
        beta = 0.9
        gamma = random.uniform(-0.10, 0.1)
        eta_1 = 0.05
        eta_2 = random.uniform(-0.05, -0.01)
        eta_3 = 0.05
        profit_1 = main1(solution1, alpha_1, alpha_2, beta, gamma)
        profit_2 = main2(solution2, alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3)
        print(profit_1 + profit_2)
    def monte_carlo_gauss(num_samples):
        for i in range(num_samples):
            # 使用正态分布代替uniform
            alpha_1 = random.gauss(0.075, 0.01)  # 均值0.075，标准差0.01
            alpha_2 = random.gauss(0.0, 0.025)  # 均值0，标准差0.025
            beta = 0.9  # 这里保持不变
            gamma = random.gauss(0.0, 0.05)  # 均值0，标准差0.05
            eta_1 = 0.05  # 这里保持不变
            eta_2 = random.gauss(-0.03, 0.01)  # 均值-0.03，标准差0.01
            eta_3 = 0.05  # 这里保持不变
            profit_1 = main1(solution1, alpha_1, alpha_2, beta, gamma)
            profit_2 = main2(solution2, alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3)
            print(profit_1 + profit_2)
def monte_carlo_left(num_samples):
    for i in range(num_samples):# 偏左分布示例
        mean_alpha_1_left = 0.05  # 将均值向左移动
        std_dev_alpha_1_left = (0.10 - 0.05) / 4  # 调整标准差以控制偏左程度
        mean_alpha_2_left = -0.025  # 调整均值靠近左侧
        std_dev_alpha_2_left = (0.05 - (-0.05)) / 4  # 标准差适当调整
        mean_gamma_left = -0.05  # 偏左
        std_dev_gamma_left = (0.1 - (-0.10)) / 4  # 控制偏左
        mean_eta_2_left = -0.03  # 偏左的均值
        std_dev_eta_2_left = (-0.01 - (-0.05)) / 4  # 控制标准差
        # 生成偏左的随机变量
        beta = 0.9
        eta_1 = 0.05
        alpha_1= np.clip(np.random.normal(mean_alpha_1_left, std_dev_alpha_1_left), 0.05, 0.10)
        alpha_2 = np.clip(np.random.normal(mean_alpha_2_left, std_dev_alpha_2_left), -0.05, 0.05)
        gamma = np.clip(np.random.normal(mean_gamma_left, std_dev_gamma_left), -0.10, 0.1)
        eta_2 = np.clip(np.random.normal(mean_eta_2_left, std_dev_eta_2_left), -0.05, -0.01)
        eta_3 = 0.05  # 这里保持不变
        profit_1 = main1(solution1, alpha_1, alpha_2, beta, gamma)
        profit_2 = main2(solution2, alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3)
        print(profit_1 + profit_2)
def monte_carlo_right(num_samples):
    for i in range(num_samples):
        mean_alpha_1 = (0.05 + 0.10) / 2
        std_dev_alpha_1 = (0.10 - 0.05) / 6  # 这个值可以根据需求调整
        mean_alpha_2 = (0.05 - 0.05) / 2
        std_dev_alpha_2 = (0.05 - (-0.05)) / 6  # 这个值可以根据需求调整
        mean_gamma = (-0.10 + 0.1) / 2
        std_dev_gamma = (0.1 - (-0.10)) / 6  # 这个值可以根据需求调整
        mean_eta_2 = (-0.05 - (-0.01)) / 2
        std_dev_eta_2 = (-0.01 - (-0.05)) / 6  # 这个值可以根据需求调整
        # 生成偏态分布的值
        alpha_1 = np.clip(np.random.normal(mean_alpha_1, std_dev_alpha_1), 0.05, 0.10)
        alpha_2 = np.clip(np.random.normal(mean_alpha_2, std_dev_alpha_2), -0.05, 0.05)
        beta = 0.9
        gamma = np.clip(np.random.normal(mean_gamma, std_dev_gamma), -0.10, 0.1)
        eta_1 = 0.05
        eta_2 = np.clip(np.random.normal(mean_eta_2, std_dev_eta_2), -0.05, -0.01)
        eta_3 = 0.05  # 这里保持不变
        profit_1 = main1(solution1, alpha_1, alpha_2, beta, gamma)
        profit_2 = main2(solution2, alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3)
        print(profit_1 + profit_2)
if __name__ == '__main__':
    num_samples = 100
    monte_carlo(num_samples)
