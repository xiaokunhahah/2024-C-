import geatpy as ea
import numpy as np
import random
import pandas as pd
# 已知量
years = 7  # 年份
plots = 26  # 地块数
plants = 15  # 农作物种类
area = [80, 55, 35, 72, 68, 55, 60, 46, 40, 28, 25, 86, 55, 44, 50, 25, 60, 45, 35, 20, 15, 13, 15, 18, 27, 20]  # 各地块面积
# 预测未来量
output = np.zeros((years, plots, plants)) # 亩产量
cost = np.zeros((years, plots, plants)) # 种植成本
price = np.zeros((years, plants)) # 销售单价
need = np.zeros((years, plants)) # 市场需求量
def forecast_1(alpha_1, alpha_2, beta, gamma):
    # 前三种地形预测量
    need_2023 = [57000, 21850, 22400, 33040, 9875, 170840, 132750, 71400, 30000, 12500, 1500, 35100, 36000, 14000,
                 10000]
    need[0, :] = need_2023
    for k in range(plants):
        for i in range(years):
            if i == 0:  # 小麦和玉米
                if k == 5 or k == 6:
                    need[i][k] *= (1 + alpha_1)
                else:
                    need[i][k] = need_2023[k] * (1 + alpha_2)
            else:
                if k == 5 or k == 6:
                    need[i][k] = need[i - 1][k] * (1 + alpha_1)
                else:
                    need[i][k] = need_2023[k] * (1 + alpha_2)
    # 亩产量
    pinghan_chan = [400, 500, 400, 350, 415, 800, 1000, 400, 630, 525, 110, 3000, 2200, 420, 525]
    titian_chan = [380, 475, 380, 330, 395, 760, 950, 380, 600, 500, 105, 2850, 2100, 400, 500]
    shanpo_chan = [360, 450, 360, 315, 375, 720, 900, 360, 570, 475, 100, 2700, 2000, 380, 475]
    output_2023 = np.zeros((plots, plants))
    output_2023[:6] = pinghan_chan
    output_2023[6:20] = titian_chan
    output_2023[20:] = shanpo_chan
    for i in range(years):
        for j in range(plots):
            for k in range(plants):
                output[i][j][k] = output_2023[j][k] * (1+beta)
    # 种植成本
    # 每年增长5%
    pinghan_cost = [400, 500, 400, 350, 415, 800, 1000, 400, 630, 525, 110, 3000, 2200, 420, 525]
    titian_cost = [380, 475, 380, 330, 395, 760, 950, 380, 600, 500, 105, 2850, 2100, 400, 500]
    shanpo_cost = [360, 450, 360, 315, 375, 720, 900, 360, 570, 475, 100, 2700, 2000, 380, 475]
    cost_2023 = np.zeros((plots, plants))
    cost_2023[:6] = pinghan_cost
    cost_2023[6:20] = titian_cost
    cost_2023[20:] = shanpo_cost
    for i in range(years):
        for j in range(plots):
            for k in range(plants):
                if i == 0:
                    cost[i][j][k] = cost_2023[j][k] * (1 + gamma)
                else:
                    cost[i][j][k] = cost[i - 1][j][k] * (1 + gamma)
    # 销售单价
    # 粮食类作物销售价格稳定
    price_2023 = [3.25, 7.5, 8.25, 7, 6.75, 3.5, 3, 6.75, 6, 7.5, 40, 1.5, 3.25, 5.5, 3.5]  # 各农作物的价格
    price[0, :] = price_2023
    for i in range(1, years):  # 假设价格保持稳定
        price[i, :] = price[i - 1, :]
    return output, need, cost, price
# 目标函数
def aim_function(A, year):
    profit = 0  # 总收益
    cost_num = 0  # 总成本
    sale = np.zeros((years+1, plants))  # 初始化每年每个作物的产量（销售量）
    # 计算产量和成本
    for j in range(plots):
        for k in range(plants):
            sale[year][k] += A[year][j][k] * area[j] * output[year-1][j][k]
            cost_num += A[year][j][k] * area[j] * cost[year-1][j][k]
    loss_num = 0
    # 限制每年的销售量不能超过 saled
    for k in range(plants):
        if sale[year][k] > need[year-1][k]:  # 限制每个作物的销售量
            loss_num += sale[year-1][k] - need[year-1][k]
            sale[year][k] = need[year-1][k]
    # 计算总收益
    for k in range(plants):
        profit += sale[year][k] * price[year-1][k]
    # 计算最终利润 = 收益 - 成本
    profit -= cost_num
    return profit
# 判断三年内是否种植过豆类（下标为0-4的作物）
def has_planted_bean(solution, plot, start_year, window):
    for year in range(start_year, start_year + window):
        if np.any(solution[year][plot][0:5] == 1):  # 种植了豆类
            return True
    return False
# 修复解，使每个地块只种植一种作物
def repair_solution(solution, year):
    for j in range(plots):  # 遍历每块地
        # 如果 year == 1，只需保证与前一年种植的不同
        if year == 1:
            previous_crop = np.argmax(solution[year - 1][j])  # 获取前一年种植的作物
            new_crop = random.choice([crop for crop in range(plants) if crop != previous_crop])  # 随机选择不同的作物
        # 如果 year >= 2，需要检查前两年是否种植过豆类
        elif year >= 2:
            # 检查前两年是否种植过豆类
            if has_planted_bean(solution, j, year - 2, 2):
                # 如果种植过豆类，只需保证与前一年种植的不同
                previous_crop = np.argmax(solution[year - 1][j])
                new_crop = random.choice([crop for crop in range(plants) if crop != previous_crop])
            else:
                # 如果前两年没有种植豆类，必须从豆类中选择一种
                new_crop = random.randint(0, 4)  # 随机选择一种豆类作物
        solution[year, j, :] = np.zeros(plants)
        solution[year, j, new_crop] = 1
    return solution  # 返回修复后的方案
# 初始化种群
def initialize_population(solution, year):
    NIND = 50  # 种群大小
    Dim = plots * plants  # 仅优化当前年份的种植方案，维度为地块数 * 作物种类数
    Encoding = 'BG'  # 二进制编码
    # 随机生成种群 (NIND, Dim)
    population = np.random.randint(0, 2, (NIND, Dim))
    # 将上一年的解作为第一个个体的初始值
    #population[0] = solution[year-1].flatten()  # 将前一年解的矩阵拉平成一维
    # 正确调用 ea.crtfld：需要二维数组作为 ranges 参数
    ranges = np.vstack([np.zeros(Dim), np.ones(Dim)])  # 变量的上下界，0 和 1
    borders = np.vstack([np.ones(Dim), np.ones(Dim)])  # 是否包含上下界，全部包含
    # 调用 crtfld 创建种群描述器
    Field = ea.crtfld(Encoding, np.array([1] * Dim), ranges, borders)
    # 返回 Population 对象
    return ea.Population(Encoding, Field, NIND)
# 遗传算法求解
def GA(solution, year):
    problem = MyProblem(solution, year)
    population = initialize_population(solution, year)
    # 使用适合二进制编码的算法模板
    algorithm = ea.soea_SGA_templet(problem, population)  # SGA 是标准遗传算法，适合二进制编码
    algorithm.MAXGEN = 2000  # 最大进化代数
    algorithm.mutOper.Pm = 0.1  # 变异概率
    algorithm.recOper.XOVR = 0.7  # 交叉概率
    algorithm.drawing = 0  # 设置绘图
    algorithm.logTras = 0
    algorithm.verbose = False
    # 求解问题
    res = ea.optimize(algorithm, verbose=False, drawing=0, outputMsg=False)
    # 从 res 中提取优化后的解
    best_variable = res['Vars'][-1]  # 获取最后一代的解（最优解）
    best_variable = best_variable.reshape(plots, plants)
    # 返回最优解
    print("最优收益：", res['ObjV'][0][0])
    return best_variable, res['ObjV'][0][0]
# 定义优化问题类
class MyProblem(ea.Problem):
    def __init__(self, solution, year):
        name = 'MyProblem'  # 问题名称
        M = 1  # 优化目标数量
        maxormins = [-1]  # 最大化目标
        Dim = years * plots * plants  # 决策变量总维数
        varTypes = [1] * Dim  # 决策变量类型，1表示二进制
        lb = np.zeros(Dim)  # 下界
        ub = np.ones(Dim)  # 上界
        lbin = np.ones(Dim)  # 下边界是否包含
        ubin = np.ones(Dim)  # 上边界是否包含
        self.year = year
        self.solution = solution
        super().__init__(name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)
    # 目标函数
    def aimFunc(self, pop):
        fitness = np.zeros(pop.sizes)  # 初始化适应度数组
        repaired_solution = repair_solution(self.solution, self.year)  # 修复指定年份的方案
        fitness[self.year] = aim_function(repaired_solution, self.year)  # 计算该解的目标函数值（利润）
        pop.ObjV = fitness.reshape(-1, 1)  # 将适应度赋给种群的目标值矩阵
# 逐年优化函数
def optimize_yearly(solution):
    # 参数设置
    alpha_1 = 0.05  # 小麦和玉米的预期销售量年增长率
    alpha_2 = -0.05  # 其他农作物的预期销售量年增长率
    beta = -0.10  # 农作物亩产量年变化率
    gamma = 0.05  # 农作物种植成本年增长率
    eta_1 = 0.05  # 蔬菜类作物销售价格增长趋势
    eta_2 = -0.05  # 食用菌销售价格下降率
    eta_3 = -0.05  # 羊肚菌销售价格下降率
    forecast_1(alpha_1, alpha_2, beta, gamma)
    profit_sum = 0
    for i in range(1, years+1):  # 从 year=1 开始逐年优化
        year = i
        better_solution, best_value = GA(solution, year)
        profit_sum += best_value
        solution[year] = better_solution
        repaired_solution = repair_solution(solution, year)
        solution = repaired_solution
    print(profit_sum)
    return solution
# 主函数
def main(solution):
    # 逐年优化种植方案
    best_solution = optimize_yearly(solution)
    # 输出每一年的最优种植方案
    for year in range(1, years+1):
        print(f"第 {year} 年的最优种植方案:")
        for plot in range(plots):
            crop = np.argmax(best_solution[year][plot])  # 获取每块地的种植作物
            print(f"  地块 {plot + 1}: 种植作物 {crop}")
if __name__ == '__main__':
    solution = np.zeros((years + 1, plots, plants))
    # 初始化2023年解 (year=0)
    solution[0] = np.zeros((plots, plants))
    # 初始方案
    num = [5, 6, 6, 0, 3, 7, 5, 1, 2, 3, 4, 7, 5, 7, 8, 9, 0, 6, 13, 14, 10, 11, 0, 12, 5, 2]
    for j, k in enumerate(num):
        solution[0, j, k] = 1
    main(solution)
    # 将 area 列表转换为数组
    area_array = np.array(area).reshape(-1, 1)  # 转为列向量，便于后续逐元素相乘
    solution_scaled = solution * area_array
    # 保存矩阵到 Excel 中的不同 sheet
    with pd.ExcelWriter('D:\\C题\问题二_鲁棒1.xlsx') as writer:
        # 从第二个矩阵开始保存 (跳过第一个矩阵)
        for i in range(0 ,solution_scaled.shape[0]):
            # 提取第 i 个矩阵
            matrix = solution_scaled[i]
            # 将矩阵转换为 DataFrame
            df = pd.DataFrame(matrix)
            # 将 DataFrame 保存到 Excel 文件中，使用不同的 sheet 名称
            df.to_excel(writer, sheet_name=f'Matrix_{i}', index=False)
    print("处理后的矩阵已保存到 Excel 文件的不同 sheet 中。")
    print("矩阵已经保存到 Excel 文件中")
