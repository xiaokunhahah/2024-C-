import geatpy as ea
from utils_ga import optimize_yearly

def optimize_yearly1(solution, alpha_1, alpha_2, beta, gamma, douPlus, xiuezheng):
# 主函数
def main1(solution,alpha_1, alpha_2, beta, gamma, douPlus, xiuzheng):
    return profit
def main2(solution,alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3, douPlus, xiuzheng):
    return profit


if __name__ == '__main__':
    solution1 = np.zeros((years1 + 1, plots1, plants1))
    # 初始化2023年解 (year=0)
    # 参数比第二问保持一致
    douPlus = [1.2, 1.1, 1]  # 种植豆类对后面种植农作物产量的影响系数
    xiuzheng = [0.4, -0.3, 0.4, -0.3]  # 成本——售价——销量 修正系数
    profit_1 = main1(solution1,alpha_1, alpha_2, beta, gamma, douPlus, xiuzheng)
    profit_2 = main2(solution2,alpha_1, alpha_2, beta, gamma, eta_1, eta_2, eta_3, douPlus, xiuzheng)
    print(profit_1 + profit_2)
