# 目标函数
def aim_function(A, year):
    profit = 0  # 总收益
    cost = 0  # 总成本
    sale = np.zeros(plants)  # 每年每个作物的销售量
    # 计算产量和成本
    for j in range(plots):
        k = np.argmax(A[year][j])  # 获取当前地块种植的作物
        if j <= 5:  # 平旱地
            sale[k] += area[j] * pinghan_chan[k]
            cost += area[j] * pinghan_cost[k]
        elif 6 <= j <= 19:  # 梯田
            sale[k] += area[j] * titian_chan[k]
            cost += area[j] * titian_cost[k]
        else:  # 山坡地
            sale[k] += area[j] * shanpo_chan[k]
            cost += area[j] * shanpo_cost[k]
    # 限制每年的销售量
    for k in range(plants):
        if sale[k] > saled[k]:
            profit += 0.5 * price[k] * (sale[k] - saled[k])
            sale[k] = saled[k]
    # 总收益
    for k in range(plants):
        profit += sale[k] * price[k]
    # 最终利润 = 收益 - 成本
    return profit - cost
